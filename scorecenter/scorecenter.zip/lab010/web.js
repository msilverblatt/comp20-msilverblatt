var express = require('express');

var app = express.createServer(express.logger());

var mongo = require('mongodb');

var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/mydb'; 
mongoUri= "mongodb://heroku_app14476617:fj90d30ftvkpop0bugd853tnpp@ds041387.mongolab.com:41387/heroku_app14476617";
app.use(express.bodyParser());
var scores;
mongo.Db.connect(mongoUri, function (err, db) {
  scores = db.collection('scores', function(er, collection) {
    //collection.insert({'mykey': 'myvalue'}, {safe: true}, function(er,rs) {
    //	console.log(er);
    //	console.log(rs);
    //});
  });
});

app.get('/highscores.json', function(req, res){
	var coll = "hello";

	mongo.Db.connect(mongoUri, function (err, db) {
  		scores = db.collection('scores', function(er, collection) {
    		coll = collection.find({'game_title':req.query.game_title}, {limit:10});
    		coll.sort({score: -1});
    		coll.toArray(function(er,docs){
    											console.log(docs);
    											res.send(docs);
    		});
  		});
	});
});

app.post('/submit.json', function(req, res){
	//req = requ;
	console.log(req.body,req.param('game_title'),req.params);

	mongo.Db.connect(mongoUri, function(err, db) {
		score = db.collection('scores', function(er, collection) {
			date = new Date;
			collection.insert({'game_title':req.param('game_title'), 
				               'username':req.param('username'), 
				               'score':parseInt(req.param('score')), 
				               'created_at':date }, {safe:true}, function(er,rs){
				               														console.log(er,rs);});
		});
	});
	res.send(req.param('username').toString());
});

app.get('/delete_all',function(req,res){
	mongo.Db.connect(mongoUri, function(err, db) {
		score = db.collection('scores', function(er, collection) {
			collection.remove();
		});
	});
})

app.get('/', function(req,res){

	mongo.Db.connect(mongoUri, function(err, db) {
		
		scores = db.collection('scores', function(er, collection){
			collection.find().toArray(function(er, docs){
				html_res = "<table><tr><th>Username</th><th>Game</th><th>Score</th></tr>";
				for (var i in docs){
					console.log(docs[i]);
					html_res+="<tr><td>" + docs[i].username + "</td><td>" + docs[i].game_title + "</td><td>" + docs[i].score + "</td></tr>";
				
				}
				html_res+="</table>";
				res.send(html_res);
			});
		});
	});

});

app.get('/usersearch', function(request, response) {
  response.send('<!DOCTYPE html><html><head></head><body><form name="search" action="/search_results" method="get">Username: <input type="text" name="username"><input value="submit" type="Submit"></body></html>');
});

app.get('/new', function(request, response) {
  response.send('<!DOCTYPE html><html><head></head><body><form name="new" action="/submit.json" method="post">Username: <input type="text" name="username"><input type="text" name="game_title"><input type="number" name="score"><input value="submit" type="submit"></form></body></html>');
});


app.get('/search_results', function(req, res){
	mongo.Db.connect(mongoUri, function(err, db){
		scores = db.collection('scores', function(er, collection){
			collection.find({ 'id':req.query.username}).toArray(function(er, docs){
				html_res = "<table><tr><th>Username</th><th>Game Title</th></tr>";
				console.log(req.query.username);
				console.log(docs);
				console.log(er);
				for (var i in docs){
					html_res+="<tr><td>" + docs[i].username + "</td><td>" + docs[i].game_title + "</td></tr>";
				}
				html_res += "</table>";
				res.send(html_res);
			});
		});
	});
});



var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});